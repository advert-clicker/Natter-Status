@echo off
setlocal
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" (
  echo.
  echo   Natter needs Python 3, which isn't on this computer yet.
  echo   Please install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and try again.
  echo.
  pause
  exit /b 1
)
%PY% "%~dp0update.py" run & exit /b
