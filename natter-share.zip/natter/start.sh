#!/usr/bin/env bash
# Start Natter (macOS and Linux). All the work, including updating itself, happens in update.py.
cd "$(dirname "$0")" || exit 1
HERE="$PWD"

ok() { [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1; }

# On a Mac without Apple's developer tools, /usr/bin/python3 is just a placeholder that pops up an install window
# when run, so don't run it unless the tools are really installed.
placeholder_is_real() {
  local d; d=$(xcode-select -p 2>/dev/null) || return 1
  [ -x "$d/usr/bin/python3" ] || [ -x /Library/Developer/CommandLineTools/usr/bin/python3 ]
}

PY=""
if ok "$HERE/runtime/bin/python3"; then PY="$HERE/runtime/bin/python3"     # Natter's own private Python, if the installer added one
else
  for c in "$(command -v python3 2>/dev/null)" /opt/homebrew/bin/python3 /usr/local/bin/python3 \
           /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/bin/python3; do
    [ -n "$c" ] || continue
    if [ "$(uname -s)" = Darwin ] && [ "$c" = /usr/bin/python3 ] && ! placeholder_is_real; then continue; fi
    if ok "$c"; then PY="$c"; break; fi
  done
fi

if [ -z "$PY" ]; then
  echo
  echo "  Natter can't find its helper program (Python 3)."
  echo "  Please run the Natter installer again; it will add it for you:"
  echo
  echo "    curl -fsSL https://raw.githubusercontent.com/advert-clicker/Natter-Status/refs/heads/main/install.sh | bash"
  echo
  exit 1
fi
exec "$PY" "$HERE/update.py" run "$@"
