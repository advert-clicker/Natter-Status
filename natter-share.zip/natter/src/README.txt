Natter - end-to-end encrypted chat

To start, go up one folder and run:
  Mac / Linux:  ./start.sh
  Windows:      double-click start-windows.bat
(Python 3 is required. Set PORT=8000 first if 5173 is taken.)

Natter checks for updates each time you start it, and installs them by itself.
To skip the check: set NATTER_NO_UPDATE=1 before starting.

First time: pick a name. Your account on the server is created for you.

Your keys and messages stay in this browser. If you clear site data you lose them -
back up your recovery phrase from Settings.
