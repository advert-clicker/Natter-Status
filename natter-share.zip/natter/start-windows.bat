@echo off
setlocal
cd /d "%~dp0"
if "%PORT%"=="" set PORT=5173

set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" (
  echo Natter needs Python 3. Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^), then run this again.
  pause
  exit /b 1
)

if not defined NATTER_NO_UPDATE if not defined NATTER_UPDATED (
  %PY% "%~dp0update.py"
  if errorlevel 10 (
    set NATTER_UPDATED=1
    start "" cmd /c "%~f0"
    exit
  )
)

cd /d "%~dp0src"
echo.
echo   Natter is running at http://localhost:%PORT%
echo   Leave this window open while you chat. Close it to stop.
echo.
echo   First time: pick a name and you're in. Your account is made automatically.
echo.
start "" http://localhost:%PORT%
%PY% -m http.server %PORT% --bind 127.0.0.1 >nul 2>nul
