#!/usr/bin/env python3
"""Natter self-updater, run by start.sh / start-windows.bat before the app starts.

Fetches version.txt from the release repo; if it names a newer version, downloads the zip, checks its SHA-256,
unpacks it safely and swaps the app files in place. Any failure leaves the current version untouched.
Exit code 10 = updated (the launcher restarts itself); anything else = carry on with what is installed.

version.txt:  line 1 = integer version, line 2 = sha256 of the zip, line 3 = zip file name (optional)
"""
import hashlib, os, re, shutil, stat, sys, tempfile, time, urllib.request, zipfile

BASE = os.environ.get("NATTER_UPDATE_URL", "https://raw.githubusercontent.com/advert-clicker/Natter-Status/refs/heads/main").rstrip("/")
ROOT = os.path.dirname(os.path.abspath(__file__))
TIMEOUT = 8
MAX_ZIP = 30 * 1024 * 1024
MAX_UNPACKED = 80 * 1024 * 1024
REPLACE = ("src", "start.sh", "start-windows.bat", "update.py", "VERSION")  # the only things an update may touch


def log(msg):
    print(f"  [update] {msg}", flush=True)


def fetch(name, limit):
    req = urllib.request.Request(f"{BASE}/{name}?t={int(time.time())}", headers={"User-Agent": "natter-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{name} is too large")
    return data


def local_version():
    try:
        return int(open(os.path.join(ROOT, "VERSION")).read().strip())
    except (OSError, ValueError):
        return 0


def safe_extract(zf, dest):
    total = 0
    for info in zf.infolist():
        name = info.filename
        parts = name.split("/")
        if name.startswith("/") or "\\" in name or ".." in parts or ":" in parts[0]:
            raise ValueError(f"unsafe path in update: {name}")
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError(f"symlink in update: {name}")
        total += info.file_size
        if total > MAX_UNPACKED:
            raise ValueError("update unpacks to too much data")
    zf.extractall(dest)


def swap(new_root):
    """Replace each whitelisted item; roll back if anything fails part-way."""
    backup = tempfile.mkdtemp(prefix=".natter-old-", dir=ROOT)
    done = []
    try:
        for item in REPLACE:
            src = os.path.join(new_root, item)
            if not os.path.exists(src):
                continue
            dst = os.path.join(ROOT, item)
            if os.path.exists(dst):
                os.replace(dst, os.path.join(backup, item))
            done.append(item)
            os.replace(src, dst)
            if item.endswith((".sh", ".py")):
                os.chmod(dst, 0o755)
    except Exception:
        for item in reversed(done):
            dst = os.path.join(ROOT, item)
            if os.path.isdir(dst) and not os.path.islink(dst):
                shutil.rmtree(dst, ignore_errors=True)
            elif os.path.exists(dst):
                os.remove(dst)
            old = os.path.join(backup, item)
            if os.path.exists(old):
                os.replace(old, dst)
        raise
    finally:
        shutil.rmtree(backup, ignore_errors=True)


def main():
    have = local_version()
    try:
        lines = fetch("version.txt", 4096).decode("utf-8", "replace").split()
    except Exception as e:
        log(f"couldn't check for updates ({type(e).__name__}); continuing with version {have}")
        return 0
    if len(lines) < 2 or not re.fullmatch(r"\d{1,9}", lines[0]) or not re.fullmatch(r"[0-9a-f]{64}", lines[1]):
        log("the update info looks wrong; ignoring it")
        return 0
    want, digest = int(lines[0]), lines[1]
    zip_name = lines[2] if len(lines) > 2 else "natter-share.zip"
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", zip_name):
        log("the update info looks wrong; ignoring it")
        return 0
    if want <= have:
        log(f"up to date (version {have})")
        return 0

    log(f"updating {have} -> {want} ...")
    work = tempfile.mkdtemp(prefix=".natter-update-", dir=ROOT)
    try:
        data = fetch(zip_name, MAX_ZIP)
        if hashlib.sha256(data).hexdigest() != digest:
            log("the download didn't match its checksum; NOT installing it")
            return 0
        zpath = os.path.join(work, "update.zip")
        open(zpath, "wb").write(data)
        out = os.path.join(work, "x")
        with zipfile.ZipFile(zpath) as zf:
            safe_extract(zf, out)
        new_root = os.path.join(out, "natter")
        for need in ("src/index.html", "start.sh", "update.py", "VERSION"):
            if not os.path.isfile(os.path.join(new_root, need)):
                raise ValueError(f"update is missing {need}")
        if int(open(os.path.join(new_root, "VERSION")).read().strip()) != want:
            raise ValueError("update's VERSION doesn't match version.txt")
        swap(new_root)
    except Exception as e:
        log(f"update failed ({type(e).__name__}: {e}); continuing with version {have}")
        return 0
    finally:
        shutil.rmtree(work, ignore_errors=True)
    log(f"updated to version {want}")
    return 10


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  # never stop the app from starting because of the updater
        log(f"unexpected error ({e}); continuing")
        sys.exit(0)
