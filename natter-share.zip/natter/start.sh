#!/usr/bin/env bash
# Start Natter and open it in your browser (macOS and Linux; needs python3). Updates itself first.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
command -v python3 >/dev/null || { echo "Natter needs Python 3 (macOS: run 'xcode-select --install'; Arch: 'sudo pacman -S python')."; exit 1; }

if [ -z "${NATTER_NO_UPDATE:-}" ] && [ -z "${NATTER_UPDATED:-}" ]; then
  rc=0
  python3 "$HERE/update.py" || rc=$?
  if [ "$rc" -eq 10 ]; then
    export NATTER_UPDATED=1
    exec "$HERE/start.sh" "$@"   # run the freshly installed launcher
  fi
fi

cd "$HERE/src"
PORT="${PORT:-5173}"
URL="http://localhost:$PORT"
echo
echo "  Natter is running at $URL"
echo "  Leave this window open while you chat. Press Ctrl+C to stop."
echo
echo "  First time: pick a name and you're in. Your account is made automatically."
echo
( sleep 1; { open "$URL" || xdg-open "$URL"; } >/dev/null 2>&1 || true ) &
exec python3 -m http.server "$PORT" --bind 127.0.0.1 >/dev/null 2>&1
