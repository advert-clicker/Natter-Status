#!/usr/bin/env bash
# Start Natter (macOS and Linux). All the work, including updating itself, happens in update.py.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo
  echo "  Natter needs Python 3, which isn't on this computer yet."
  echo "  Mac: run   xcode-select --install   and try again.   Linux: install the 'python3' package."
  echo
  exit 1
fi
exec python3 "$PWD/update.py" run "$@"
