#!/usr/bin/env python3
"""Natter launcher and self-updater.  start.sh / start-windows.bat just call:   python3 update.py run

  run      friendly start-up screen: check for an update, install it, start Natter, open the browser
  (none)   updater only, quiet. Exit code 10 = updated (older launchers restart themselves on that)

Updating: fetch version.txt from the release repo; if it names a newer version, download the zip, check its
SHA-256, unpack it safely and swap the app files in place. Any failure leaves the current version untouched.

version.txt:  line 1 = integer version, line 2 = sha256 of the zip, line 3 = zip file name (optional)
"""
import functools, hashlib, http.server, os, re, shutil, stat, subprocess, sys, tempfile, threading, time, urllib.request, webbrowser, zipfile

BASE = os.environ.get("NATTER_UPDATE_URL", "https://raw.githubusercontent.com/advert-clicker/Natter-Status/refs/heads/main").rstrip("/")
ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
TIMEOUT = 8
MAX_ZIP = 30 * 1024 * 1024
MAX_UNPACKED = 80 * 1024 * 1024
REPLACE = ("src", "start.sh", "start-windows.bat", "update.py", "VERSION")  # the only things an update may touch


# ------------------------------------------------------------------------------------------------ updating

def fetch(name, limit):
    req = urllib.request.Request(f"{BASE}/{name}?t={int(time.time())}", headers={"User-Agent": "natter-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{name} is too large")
    return data


def local_version():
    try:
        return int(open(os.path.join(ROOT, "VERSION")).read().strip())
    except (OSError, ValueError):
        return 0


def safe_extract(zf, dest):
    total = 0
    for info in zf.infolist():
        name = info.filename
        parts = name.split("/")
        if name.startswith("/") or "\\" in name or ".." in parts or ":" in parts[0]:
            raise ValueError(f"unsafe path in update: {name}")
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError(f"symlink in update: {name}")
        total += info.file_size
        if total > MAX_UNPACKED:
            raise ValueError("update unpacks to too much data")
    zf.extractall(dest)


def swap(new_root):
    """Replace each whitelisted item; roll back if anything fails part-way."""
    backup = tempfile.mkdtemp(prefix=".natter-old-", dir=ROOT)
    done = []
    try:
        for item in REPLACE:
            src = os.path.join(new_root, item)
            if not os.path.exists(src):
                continue
            dst = os.path.join(ROOT, item)
            if os.path.exists(dst):
                os.replace(dst, os.path.join(backup, item))
            done.append(item)
            os.replace(src, dst)
            if item.endswith((".sh", ".py")):
                os.chmod(dst, 0o755)
    except Exception:
        for item in reversed(done):
            dst = os.path.join(ROOT, item)
            if os.path.isdir(dst) and not os.path.islink(dst):
                shutil.rmtree(dst, ignore_errors=True)
            elif os.path.exists(dst):
                os.remove(dst)
            old = os.path.join(backup, item)
            if os.path.exists(old):
                os.replace(old, dst)
        raise
    finally:
        shutil.rmtree(backup, ignore_errors=True)


def update():
    """Check for and install an update. Returns (status, message); status is one of
    current | updated | offline | ignored | refused | failed."""
    have = local_version()
    try:
        lines = fetch("version.txt", 4096).decode("utf-8", "replace").split()
    except Exception as e:
        return "offline", f"couldn't check for updates ({type(e).__name__}); continuing with version {have}"
    if len(lines) < 2 or not re.fullmatch(r"\d{1,9}", lines[0]) or not re.fullmatch(r"[0-9a-f]{64}", lines[1]):
        return "ignored", "the update info looks wrong; ignoring it"
    want, digest = int(lines[0]), lines[1]
    zip_name = lines[2] if len(lines) > 2 else "natter-share.zip"
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", zip_name):
        return "ignored", "the update info looks wrong; ignoring it"
    if want <= have:
        return "current", f"up to date (version {have})"

    work = tempfile.mkdtemp(prefix=".natter-update-", dir=ROOT)
    try:
        data = fetch(zip_name, MAX_ZIP)
        if hashlib.sha256(data).hexdigest() != digest:
            return "refused", "the download didn't match its checksum, so it was NOT installed"
        zpath = os.path.join(work, "update.zip")
        with open(zpath, "wb") as f:
            f.write(data)
        out = os.path.join(work, "x")
        with zipfile.ZipFile(zpath) as zf:
            safe_extract(zf, out)
        new_root = os.path.join(out, "natter")
        for need in ("src/index.html", "start.sh", "update.py", "VERSION"):
            if not os.path.isfile(os.path.join(new_root, need)):
                raise ValueError(f"update is missing {need}")
        with open(os.path.join(new_root, "VERSION")) as f:
            if int(f.read().strip()) != want:
                raise ValueError("update's VERSION doesn't match version.txt")
        swap(new_root)
    except Exception as e:
        return "failed", f"update failed ({type(e).__name__}: {e}); continuing with version {have}"
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return "updated", f"updated {have} -> {want}"


# --------------------------------------------------------------------------------------------- the screen

if os.name == "nt":
    os.system("")  # switches on colour codes in Windows 10+ consoles
try:
    sys.stdout.reconfigure(errors="replace", line_buffering=True)
except Exception:
    pass

COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR") and os.environ.get("TERM", "x") != "dumb"
UTF8 = (getattr(sys.stdout, "encoding", "") or "").lower().replace("-", "") in ("utf8", "utf8sig")


def c(code, s):
    return f"\033[{code}m{s}\033[0m" if COLOR else s


bold = lambda s: c("1", s)
dim = lambda s: c("2", s)
green = lambda s: c("38;5;77", s)
red = lambda s: c("38;5;203", s)
yellow = lambda s: c("38;5;221", s)
blue = lambda s: c("38;5;75", s)
pink = lambda s: c("38;5;177", s)
TICK, CROSS = ("✔", "✘") if UTF8 else ("OK", "X")
FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏" if UTF8 else "|/-\\"
TL, TR, BL, BR, H, V = ("╭", "╮", "╰", "╯", "─", "│") if UTF8 else ("+", "+", "+", "+", "-", "|")
W = 46


def say(s=""):
    print("  " + s)


def box(lines, paint):
    say(paint(TL + H * W + TR))
    for ln in lines:
        pad = W - len(re.sub(r"\033\[[0-9;]*m", "", ln))
        say(paint(V) + ln + " " * max(pad, 0) + paint(V))
    say(paint(BL + H * W + BR))


def banner():
    if COLOR:
        print("\033[2J\033[H", end="")
    print()
    box(["", "     " + bold("N A T T E R"), "     Private chat for you and your friends", ""], pink)
    print()


def spinner(message, fn):
    """Run fn() in a thread, animating while we wait. Returns fn's result."""
    box_result = {}
    t = threading.Thread(target=lambda: box_result.update(r=fn()), daemon=True)
    t.start()
    if not COLOR:
        say(message + " ...")
        t.join()
        return box_result.get("r")
    i = 0
    while t.is_alive():
        print(f"\r  {blue(FRAMES[i % len(FRAMES)])} {message}", end="", flush=True)
        i += 1
        time.sleep(0.1)
    print("\r\033[K", end="")
    return box_result.get("r")


def pause():
    if sys.stdin and sys.stdin.isatty():
        try:
            input("  Press Enter to close this window... ")
        except (EOFError, KeyboardInterrupt):
            pass


def fail(title, *details):
    print()
    say(red(f"{CROSS} {title}"))
    for d in details:
        say(d)
    print()
    pause()
    sys.exit(1)


def is_natter(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2) as r:
            return b"<title>Natter</title>" in r.read(4096)
    except Exception:
        return False


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):  # no request log: nothing about who opens what
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")  # always check for the newest files after an update
        super().end_headers()


def serve(version):
    port = int(os.environ.get("PORT") or 5173)
    url = f"http://localhost:{port}"
    try:
        httpd = http.server.ThreadingHTTPServer(("127.0.0.1", port), functools.partial(Handler, directory=SRC))
    except OSError:
        if is_natter(port):
            say(green(f"{TICK} Natter is already running"))
            say(dim("Opening it for you again."))
            if not os.environ.get("NATTER_NO_BROWSER"):
                webbrowser.open(url)
            print()
            say(f"If you can't see it, open {bold(url)} in your browser.")
            print()
            return
        fail(
            f"Port {port} is being used by another program.",
            "Natter needs that spot to keep your account and chats.",
            "Please close the other program (or another Natter window) and try again.",
            dim(f"Technical note: something else is listening on port {port}."),
            dim("(Using a different port starts you with a fresh, empty Natter, so I won't do it for you.)"),
        )
    say(green(f"{TICK} Natter is ready"))
    print()
    box(["", "   " + bold("Natter is running at"), "   " + blue(url), ""], green)
    print()
    say(f"Your web browser should open by itself. If it doesn't, type that address into it.")
    say(bold("Leave this window open while you chat."))
    say(f"To stop Natter, press {bold('Ctrl+C')} (or just close this window).")
    print()
    say(dim(f"First time? Pick a name and you're in. Version {version}."))
    print()
    if not os.environ.get("NATTER_NO_BROWSER"):
        threading.Timer(0.8, webbrowser.open, [url]).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    print()
    say(pink("Natter has stopped. See you soon!"))
    print()


def run():
    if not os.path.isfile(os.path.join(SRC, "index.html")):
        fail("Natter's files are missing.", "Please run the installer again.")
    banner()
    if not os.environ.get("NATTER_NO_UPDATE") and not os.environ.get("NATTER_UPDATED"):
        status, msg = spinner("Checking for a newer Natter", update) or ("failed", "")
        if status == "updated":
            say(green(f"{TICK} Updated to the newest version"))
            os.environ["NATTER_UPDATED"] = "1"
            print()
            again = [sys.executable, os.path.join(ROOT, "update.py"), "run"]  # start the new code
            if os.name == "nt":  # execv mangles paths with spaces on Windows
                sys.exit(subprocess.call(again))
            os.execv(sys.executable, again)
        elif status == "current":
            say(green(f"{TICK} You have the newest version"))
        elif status == "offline":
            say(yellow("! Couldn't check for updates (are you online?). Starting anyway."))
        elif status in ("refused", "failed", "ignored"):
            say(yellow("! Couldn't install an update, so I'm starting the version you have."))
            say(dim(msg))
    say(dim("Starting Natter ..."))
    serve(local_version())


def main():
    status, msg = update()
    print(f"  [update] {msg}", flush=True)
    return 10 if status == "updated" else 0


if __name__ == "__main__":
    try:
        if sys.argv[1:2] == ["run"]:
            run()
            sys.exit(0)
        sys.exit(main())
    except KeyboardInterrupt:
        print()
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as e:  # never leave people staring at a stack trace
        if sys.argv[1:2] == ["run"]:
            fail("Something unexpected went wrong.", dim(f"{type(e).__name__}: {e}"))
        print(f"  [update] unexpected error ({e}); continuing", flush=True)
        sys.exit(0)
